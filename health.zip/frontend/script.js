let totalCaloriesConsumed = 0;
let totalCaloriesBurned = 0;

// Nutrition form submit
document.getElementById("nutrition-form").addEventListener("submit", async function (e) {
  e.preventDefault();
  const foodInput = document.getElementById("food-input").value.trim();
  if (foodInput === "") return;

  try {
    const response = await fetch("http://localhost:5000/nutrition", {   // updated URL
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: foodInput }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log(data);

    if (data && data.foods && data.foods.length > 0) {
      const food = data.foods[0];
      const nutritionInfo = `Food: ${food.food_name}
Calories: ${food.nf_calories} kcal
Carbs: ${food.nf_total_carbohydrate} g
Protein: ${food.nf_protein} g
Fat: ${food.nf_total_fat} g`;

      document.getElementById("nutrition-result").innerText = nutritionInfo;

      totalCaloriesConsumed += food.nf_calories;
      updateSummary();
    } else {
      document.getElementById("nutrition-result").innerText = "No nutrition data found.";
    }
  } catch (error) {
    console.error("Error fetching nutrition data:", error);
    document.getElementById("nutrition-result").innerText = "Error fetching nutrition data.";
  }
});

// Exercise form submit
document.getElementById("exercise-form").addEventListener("submit", async function (e) {
  e.preventDefault();
  const exerciseInput = document.getElementById("exercise-input").value.trim();
  if (exerciseInput === "") return;

  try {
    const response = await fetch("http://localhost:5000/exercise", {    // updated URL
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: exerciseInput }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log(data);

    if (data && data.exercises && data.exercises.length > 0) {
      const exercise = data.exercises[0];
      const exerciseInfo = `Exercise: ${exercise.name}
Duration: ${exercise.duration_min} minutes
Calories Burned: ${exercise.nf_calories} kcal`;

      document.getElementById("exercise-result").innerText = exerciseInfo;

      totalCaloriesBurned += exercise.nf_calories;
      updateSummary();
    } else {
      document.getElementById("exercise-result").innerText = "No exercise data found.";
    }
  } catch (error) {
    console.error("Error fetching exercise data:", error);
    document.getElementById("exercise-result").innerText = "Error fetching exercise data.";
  }
});

// Update daily summary
function updateSummary() {
  const netCalories = totalCaloriesConsumed - totalCaloriesBurned;
  document.getElementById("summary-consumed").innerText = totalCaloriesConsumed.toFixed(2);
  document.getElementById("summary-burned").innerText = totalCaloriesBurned.toFixed(2);
  document.getElementById("summary-net").innerText = netCalories.toFixed(2);
}
