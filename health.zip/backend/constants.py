USER_END_POINT = "https://pixe.la/v1/users"
USER_DB_FILE = "resources/users.csv"

EXERCISE_END_POINT = "https://trackapi.nutritionix.com/v2/natural/exercise"
EXERCISE_DB_FILE = "resources/exercise_data.csv"

NUTRITION_END_POINT = "https://trackapi.nutritionix.com/v2/natural/nutrients"
NUTRITION_DB_FILE = "resources/nutrition_data.csv"
